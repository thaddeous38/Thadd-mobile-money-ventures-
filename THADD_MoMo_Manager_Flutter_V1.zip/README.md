# THADD MOBILE MONEY VENTURES — Flutter V1

## Features
- MTN / Telecel transaction register
- Cash-in, cash-out and transfer/other categories
- Transaction amount, commission and optional note
- Daily and monthly transaction-volume and commission reports
- Manual cash, MTN float and Telecel float balance snapshots
- Local SQLite database (works offline after installation)

## Important limitations
This is a starter management app, not a mobile-money wallet or payment processor.
It does not connect to MTN or Telecel systems, automatically move money, automatically reconcile balances, export reports, or back up to the cloud.
Commission is entered by the shop operator and shown as commission recorded, before expenses.
Use only after confirming the transaction in the official agent system. Never store MoMo PINs/passwords in this app.
Long-press a transaction row to delete it; this is intended for test records and is not a full audit log.

## Run from an Android phone only (no computer)
1. Install a reputable Android IDE that supports Flutter/Dart projects, or use a cloud development environment that can build Flutter Android apps. Availability and capabilities vary by app/service.
2. Create a Flutter project named `thadd_mobile_money_ventures`.
3. Replace `pubspec.yaml` and `lib/main.dart` with the files in this package.
4. In the project terminal run:
   `flutter pub get`
5. Build an APK:
   `flutter build apk --debug`
   For a release APK after testing:
   `flutter build apk --release`
6. Install the generated APK on your Android phone. For a debug build, output is usually:
   `build/app/outputs/flutter-apk/app-debug.apk`

A regular Android phone cannot run the standard Flutter SDK toolchain by itself in the same way a computer does. If your phone IDE cannot run Flutter build commands, use a browser-based development workspace or borrow a computer for the build step. Do not install unknown APK-building apps or grant unnecessary permissions.

## Recommended test checklist
1. Open the app; check all four tabs.
2. Add an MTN cash-in: amount GH₵100, commission GH₵1.50.
3. Add a Telecel cash-out: amount GH₵50, commission GH₵1.00.
4. Confirm transaction count = 2, total volume = GH₵150, and commission recorded = GH₵2.50 for today.
5. Enter cash = 500, MTN float = 800, Telecel float = 300; save and reopen the Float tab to verify values remain.
6. Close and reopen the app; check transaction records remain.
7. Test invalid amounts (zero or negative) and confirm they are rejected.
8. Do not use real customer records for initial tests; use fictional/sample data.
