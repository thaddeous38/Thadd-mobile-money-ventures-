import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AppDb.instance.database;
  runApp(const ThaddMoMoApp());
}

class ThaddMoMoApp extends StatelessWidget {
  const ThaddMoMoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'THADD MOBILE MONEY VENTURES',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087F5B)),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5F7F8),
      ),
      home: const HomeScreen(),
    );
  }
}

class AppDb {
  AppDb._();
  static final AppDb instance = AppDb._();
  Database? _db;

  Future<Database> get database async {
    if (_db != null) return _db!;
    final root = await getDatabasesPath();
    _db = await openDatabase(
      p.join(root, 'thadd_momo_v1.db'),
      version: 1,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            network TEXT NOT NULL,
            type TEXT NOT NULL,
            amount REAL NOT NULL,
            commission REAL NOT NULL DEFAULT 0,
            note TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute('''
          CREATE TABLE balances (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            cash REAL NOT NULL DEFAULT 0,
            mtn_float REAL NOT NULL DEFAULT 0,
            telecel_float REAL NOT NULL DEFAULT 0
          )
        ''');
        await db.insert('balances', {
          'id': 1, 'cash': 0.0, 'mtn_float': 0.0, 'telecel_float': 0.0
        });
      },
    );
    return _db!;
  }

  Future<List<Map<String, Object?>>> transactions() async {
    final db = await database;
    return db.query('transactions', orderBy: 'created_at DESC, id DESC');
  }

  Future<void> addTransaction({
    required String network,
    required String type,
    required double amount,
    required double commission,
    required String note,
  }) async {
    final db = await database;
    await db.insert('transactions', {
      'network': network,
      'type': type,
      'amount': amount,
      'commission': commission,
      'note': note.trim(),
      'created_at': DateTime.now().toIso8601String(),
    });
  }

  Future<Map<String, Object?>> balance() async {
    final db = await database;
    final rows = await db.query('balances', where: 'id = 1', limit: 1);
    return rows.first;
  }

  Future<void> saveBalances({
    required double cash,
    required double mtnFloat,
    required double telecelFloat,
  }) async {
    final db = await database;
    await db.update('balances', {
      'cash': cash,
      'mtn_float': mtnFloat,
      'telecel_float': telecelFloat,
    }, where: 'id = 1');
  }

  Future<void> deleteTransaction(int id) async {
    final db = await database;
    await db.delete('transactions', where: 'id = ?', whereArgs: [id]);
  }
}

String money(num value) => 'GH₵${value.toStringAsFixed(2)}';

DateTime parseDate(Object? value) =>
    DateTime.tryParse(value?.toString() ?? '') ?? DateTime.now();

bool sameDay(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month && a.day == b.day;

bool sameMonth(DateTime a, DateTime b) =>
    a.year == b.year && a.month == b.month;

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _index = 0;
  int _refreshKey = 0;

  Future<void> refresh() async {
    if (mounted) setState(() => _refreshKey++);
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      DashboardPage(key: ValueKey('dash$_refreshKey'), onChanged: refresh),
      TransactionsPage(key: ValueKey('tx$_refreshKey'), onChanged: refresh),
      FloatPage(key: ValueKey('float$_refreshKey'), onChanged: refresh),
      ReportsPage(key: ValueKey('report$_refreshKey')),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('THADD MOBILE MONEY VENTURES',
            style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
        backgroundColor: Colors.white,
      ),
      body: pages[_index],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (value) => setState(() => _index = value),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Transactions'),
          NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Float'),
          NavigationDestination(icon: Icon(Icons.bar_chart), label: 'Reports'),
        ],
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  final Future<void> Function() onChanged;
  const DashboardPage({super.key, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, Object?>>>(
      future: AppDb.instance.transactions(),
      builder: (context, snapshot) {
        final rows = snapshot.data ?? [];
        final now = DateTime.now();
        final today = rows.where((r) => sameDay(parseDate(r['created_at']), now)).toList();
        final todayProfit = today.fold<double>(0, (sum, r) => sum + ((r['commission'] as num?)?.toDouble() ?? 0));
        final monthProfit = rows.where((r) => sameMonth(parseDate(r['created_at']), now))
            .fold<double>(0, (sum, r) => sum + ((r['commission'] as num?)?.toDouble() ?? 0));
        final todayVolume = today.fold<double>(0, (sum, r) => sum + ((r['amount'] as num?)?.toDouble() ?? 0));
        return RefreshIndicator(
          onRefresh: onChanged,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Container(
                padding: const EdgeInsets.all(18),
                decoration: BoxDecoration(
                  color: const Color(0xFF087F5B),
                  borderRadius: BorderRadius.circular(18),
                ),
                child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('Welcome to your shop dashboard',
                      style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  SizedBox(height: 6),
                  Text('Record transactions and monitor your business.',
                      style: TextStyle(color: Colors.white70)),
                ]),
              ),
              const SizedBox(height: 16),
              GridView.count(
                crossAxisCount: MediaQuery.of(context).size.width > 600 ? 3 : 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                crossAxisSpacing: 12,
                mainAxisSpacing: 12,
                childAspectRatio: 1.25,
                children: [
                  StatCard(title: "Today's commission", value: money(todayProfit), icon: Icons.trending_up),
                  StatCard(title: 'This month', value: money(monthProfit), icon: Icons.calendar_month),
                  StatCard(title: "Today's volume", value: money(todayVolume), icon: Icons.swap_horiz),
                  StatCard(title: "Today's transactions", value: '${today.length}', icon: Icons.receipt),
                ],
              ),
              const SizedBox(height: 18),
              const Text('Important', style: TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Card(child: Padding(
                padding: EdgeInsets.all(14),
                child: Text('Commission is used as a simple profit estimate in Version 1. Enter the commission you actually earned for each transaction. Add shop expenses separately in a future version for net profit reporting.'),
              )),
              const SizedBox(height: 8),
              FilledButton.icon(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => AddTransactionPage(onSaved: onChanged))),
                icon: const Icon(Icons.add),
                label: const Text('Record a transaction'),
              ),
            ],
          ),
        );
      },
    );
  }
}

class StatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  const StatCard({super.key, required this.title, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => Card(
    child: Padding(
      padding: const EdgeInsets.all(13),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(icon, color: Theme.of(context).colorScheme.primary),
        const SizedBox(height: 8),
        Text(title, style: const TextStyle(fontSize: 12), maxLines: 2),
        const SizedBox(height: 4),
        FittedBox(fit: BoxFit.scaleDown, alignment: Alignment.centerLeft,
          child: Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold))),
      ]),
    ),
  );
}

class TransactionsPage extends StatelessWidget {
  final Future<void> Function() onChanged;
  const TransactionsPage({super.key, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (_) => AddTransactionPage(onSaved: onChanged))),
        icon: const Icon(Icons.add),
        label: const Text('Add transaction'),
      ),
      body: FutureBuilder<List<Map<String, Object?>>>(
        future: AppDb.instance.transactions(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
          final rows = snapshot.data!;
          if (rows.isEmpty) return const Center(child: Text('No transactions yet. Tap Add transaction to begin.'));
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
            itemCount: rows.length,
            separatorBuilder: (_, __) => const SizedBox(height: 4),
            itemBuilder: (context, index) {
              final r = rows[index];
              final amount = (r['amount'] as num).toDouble();
              final commission = (r['commission'] as num).toDouble();
              final dt = parseDate(r['created_at']);
              return Card(child: ListTile(
                leading: CircleAvatar(child: Icon(r['type'] == 'Cash-in' ? Icons.call_received : Icons.call_made)),
                title: Text('${r['network']} • ${r['type']}'),
                subtitle: Text('${dt.day}/${dt.month}/${dt.year} ${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}\n${r['note'] ?? ''}'),
                isThreeLine: (r['note']?.toString().isNotEmpty ?? false),
                trailing: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.end, children: [
                  Text(money(amount), style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('Comm. ${money(commission)}', style: const TextStyle(fontSize: 11)),
                ]),
                onLongPress: () async {
                  final yes = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(
                    title: const Text('Delete transaction?'),
                    content: const Text('This removes the record from this device.'),
                    actions: [
                      TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                      TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
                    ],
                  ));
                  if (yes == true) {
                    await AppDb.instance.deleteTransaction(r['id'] as int);
                    await onChanged();
                  }
                },
              ));
            },
          );
        },
      ),
    );
  }
}

class AddTransactionPage extends StatefulWidget {
  final Future<void> Function() onSaved;
  const AddTransactionPage({super.key, required this.onSaved});
  @override
  State<AddTransactionPage> createState() => _AddTransactionPageState();
}

class _AddTransactionPageState extends State<AddTransactionPage> {
  final _formKey = GlobalKey<FormState>();
  final _amount = TextEditingController();
  final _commission = TextEditingController(text: '0');
  final _note = TextEditingController();
  String _network = 'MTN';
  String _type = 'Cash-in';
  bool _saving = false;

  @override
  void dispose() {
    _amount.dispose();
    _commission.dispose();
    _note.dispose();
    super.dispose();
  }

  double parseMoney(String value) => double.tryParse(value.trim()) ?? -1;

  Future<void> save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    await AppDb.instance.addTransaction(
      network: _network,
      type: _type,
      amount: parseMoney(_amount.text),
      commission: parseMoney(_commission.text),
      note: _note.text,
    );
    await widget.onSaved();
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Record transaction')),
    body: Form(
      key: _formKey,
      child: ListView(padding: const EdgeInsets.all(16), children: [
        DropdownButtonFormField<String>(
          value: _network,
          decoration: const InputDecoration(labelText: 'Network', border: OutlineInputBorder()),
          items: const [DropdownMenuItem(value: 'MTN', child: Text('MTN MoMo')), DropdownMenuItem(value: 'Telecel', child: Text('Telecel Cash'))],
          onChanged: (v) => setState(() => _network = v ?? 'MTN'),
        ),
        const SizedBox(height: 14),
        DropdownButtonFormField<String>(
          value: _type,
          decoration: const InputDecoration(labelText: 'Transaction type', border: OutlineInputBorder()),
          items: const [
            DropdownMenuItem(value: 'Cash-in', child: Text('Cash-in / Deposit')),
            DropdownMenuItem(value: 'Cash-out', child: Text('Cash-out / Withdrawal')),
            DropdownMenuItem(value: 'Transfer', child: Text('Transfer / Other')),
          ],
          onChanged: (v) => setState(() => _type = v ?? 'Cash-in'),
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _amount,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Transaction amount (GH₵)', border: OutlineInputBorder()),
          validator: (v) {
            final n = double.tryParse((v ?? '').trim());
            if (n == null || n <= 0) return 'Enter an amount greater than zero';
            return null;
          },
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _commission,
          keyboardType: const TextInputType.numberWithOptions(decimal: true),
          decoration: const InputDecoration(labelText: 'Commission earned (GH₵)', border: OutlineInputBorder()),
          validator: (v) {
            final n = double.tryParse((v ?? '').trim());
            if (n == null || n < 0) return 'Enter zero or a positive commission';
            return null;
          },
        ),
        const SizedBox(height: 14),
        TextFormField(
          controller: _note,
          decoration: const InputDecoration(labelText: 'Note / reference (optional)', border: OutlineInputBorder()),
          maxLength: 100,
        ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: _saving ? null : save,
          icon: const Icon(Icons.save),
          label: Text(_saving ? 'Saving...' : 'Save transaction'),
        ),
        const SizedBox(height: 8),
        const Text('Only record the transaction after confirming it in the official MTN or Telecel agent system. Do not enter PINs or passwords here.',
          style: TextStyle(color: Colors.black54)),
      ]),
    ),
  );
}

class FloatPage extends StatefulWidget {
  final Future<void> Function() onChanged;
  const FloatPage({super.key, required this.onChanged});
  @override
  State<FloatPage> createState() => _FloatPageState();
}

class _FloatPageState extends State<FloatPage> {
  final _cash = TextEditingController();
  final _mtn = TextEditingController();
  final _telecel = TextEditingController();
  bool _loaded = false;
  bool _saving = false;

  @override
  void dispose() {
    _cash.dispose(); _mtn.dispose(); _telecel.dispose();
    super.dispose();
  }

  Future<void> load() async {
    final b = await AppDb.instance.balance();
    _cash.text = (b['cash'] as num).toStringAsFixed(2);
    _mtn.text = (b['mtn_float'] as num).toStringAsFixed(2);
    _telecel.text = (b['telecel_float'] as num).toStringAsFixed(2);
    if (mounted) setState(() => _loaded = true);
  }

  double value(TextEditingController c) => double.tryParse(c.text.trim()) ?? -1;

  Future<void> save() async {
    if (value(_cash) < 0 || value(_mtn) < 0 || value(_telecel) < 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Enter valid balances (zero or above).')));
      return;
    }
    setState(() => _saving = true);
    await AppDb.instance.saveBalances(cash: value(_cash), mtnFloat: value(_mtn), telecelFloat: value(_telecel));
    await widget.onChanged();
    if (mounted) {
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Balances saved.')));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (!_loaded) load();
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Cash and float balances', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('Enter the balances you verify in your shop and official agent wallets. Version 1 stores these as manual snapshots; it does not automatically reconcile transactions.'),
      const SizedBox(height: 18),
      _balanceField(_cash, 'Physical cash in shop (GH₵)', Icons.payments),
      const SizedBox(height: 12),
      _balanceField(_mtn, 'MTN electronic float (GH₵)', Icons.account_balance_wallet),
      const SizedBox(height: 12),
      _balanceField(_telecel, 'Telecel electronic float (GH₵)', Icons.account_balance_wallet_outlined),
      const SizedBox(height: 18),
      FilledButton.icon(onPressed: _saving ? null : save, icon: const Icon(Icons.save), label: Text(_saving ? 'Saving...' : 'Save balances')),
    ]);
  }

  Widget _balanceField(TextEditingController c, String label, IconData icon) => TextField(
    controller: c,
    keyboardType: const TextInputType.numberWithOptions(decimal: true),
    decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon), border: const OutlineInputBorder()),
  );
}

class ReportsPage extends StatelessWidget {
  const ReportsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Map<String, Object?>>>(
      future: AppDb.instance.transactions(),
      builder: (context, snapshot) {
        if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
        final rows = snapshot.data!;
        final now = DateTime.now();
        double sumFor(bool Function(DateTime) dateFilter, String field) =>
            rows.where((r) => dateFilter(parseDate(r['created_at'])))
                .fold<double>(0, (sum, r) => sum + ((r[field] as num?)?.toDouble() ?? 0));
        final todayVolume = sumFor((d) => sameDay(d, now), 'amount');
        final todayCommission = sumFor((d) => sameDay(d, now), 'commission');
        final monthVolume = sumFor((d) => sameMonth(d, now), 'amount');
        final monthCommission = sumFor((d) => sameMonth(d, now), 'commission');
        final mtnCount = rows.where((r) => r['network'] == 'MTN').length;
        final telecelCount = rows.where((r) => r['network'] == 'Telecel').length;
        return ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Business reports', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          _reportCard('TODAY', [
            ('Transaction volume', money(todayVolume)),
            ('Commission recorded', money(todayCommission)),
          ]),
          const SizedBox(height: 12),
          _reportCard('THIS MONTH', [
            ('Transaction volume', money(monthVolume)),
            ('Commission recorded', money(monthCommission)),
          ]),
          const SizedBox(height: 12),
          _reportCard('NETWORK ACTIVITY', [
            ('MTN transactions (all time)', '$mtnCount'),
            ('Telecel transactions (all time)', '$telecelCount'),
            ('Total transaction records', '${rows.length}'),
          ]),
          const SizedBox(height: 12),
          const Card(child: Padding(
            padding: EdgeInsets.all(14),
            child: Text('Report note: transaction volume is not profit. Commission recorded is a profit estimate before expenses. This starter does not yet include expense entry, automatic cash/float updates, CSV export, cloud sync, or multi-staff accounts.'),
          )),
        ]);
      },
    );
  }

  Widget _reportCard(String title, List<(String, String)> items) => Card(
    child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 8),
        ...items.map((item) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Row(children: [
            Expanded(child: Text(item.$1)),
            Text(item.$2, style: const TextStyle(fontWeight: FontWeight.bold)),
          ]),
        )),
      ]),
    ),
  );
}
